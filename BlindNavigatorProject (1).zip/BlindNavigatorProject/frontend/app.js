// Simple BlindNavigator frontend demo
// Features: fetch products, TTS, SpeechRecognition commands, voice feedback, contrast and font controls

const productListEl = document.getElementById('product-list');
const cartListEl = document.getElementById('cart-list');
const voiceStartBtn = document.getElementById('voice-start');
const voiceStopBtn = document.getElementById('voice-stop');
const toggleContrastBtn = document.getElementById('toggle-contrast');
const increaseFontBtn = document.getElementById('increase-font');
const decreaseFontBtn = document.getElementById('decrease-font');

let products = [];
let cart = [];

// --- Text-to-Speech helpers ---
function speak(text, options={rate:1, pitch:1, lang:'en-US'}){
  if(!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.rate = options.rate;
  utter.pitch = options.pitch;
  utter.lang = options.lang;
  window.speechSynthesis.speak(utter);
}

function stopSpeaking(){ if('speechSynthesis' in window) window.speechSynthesis.cancel(); }

// --- Fetch products from backend ---
async function loadProducts(){
  try{
    const res = await fetch('/api/products');
    products = await res.json();
    renderProducts();
  }catch(e){
    // fallback sample data
    products = [
      {id:1,name:'LED Lamp',price:1200,description:'Bright lamp for reading'},
      {id:2,name:'Talking Watch',price:2500,description:'Voice-enabled watch'}
    ];
    renderProducts();
  }
}

function renderProducts(){
  productListEl.innerHTML = '';
  products.forEach((p, idx)=>{
    const card = document.createElement('div');
    card.className = 'product';
    card.setAttribute('data-id', p.id);
    card.innerHTML = `<h3>${idx+1}. ${p.name} — Rs ${p.price}</h3><p>${p.description}</p>`;
    productListEl.appendChild(card);
  });
}

function renderCart(){
  if(cart.length===0){ cartListEl.textContent = 'Cart is empty.'; return; }
  cartListEl.innerHTML = '';
  cart.forEach(item=>{
    const div = document.createElement('div');
    div.textContent = `${item.name} x ${item.qty} — Rs ${item.price*item.qty}`;
    cartListEl.appendChild(div);
  });
}

function addToCartByIndex(index){
  const p = products[index];
  if(!p) { speak('Product not found'); return; }
  const existing = cart.find(c=>c.id===p.id);
  if(existing) existing.qty += 1; else cart.push({id:p.id,name:p.name,price:p.price,qty:1});
  speak(`${p.name} added to cart.`);
  renderCart();
}

// --- Accessibility controls ---
let contrastOn = false;
let currentFontSize = 18;
function toggleContrast(){
  contrastOn = !contrastOn;
  document.body.classList.toggle('contrast', contrastOn);
  speak(contrastOn ? 'High contrast mode enabled' : 'High contrast mode disabled');
}
function changeFont(delta){
  currentFontSize = Math.max(14, currentFontSize + delta);
  document.documentElement.style.setProperty('--font-size', currentFontSize + 'px');
  speak('Font size updated');
}

// --- Speech Recognition & Command parsing ---
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition;
if(SpeechRecognition){
  recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.continuous = true;

  recognition.onresult = (evt) => {
    const transcript = Array.from(evt.results).map(r=>r[0].transcript).join(' ').trim().toLowerCase();
    console.log('Heard:', transcript);
    parseCommand(transcript);
  };
  recognition.onend = () => { console.log('Recognition ended'); };
  recognition.onerror = (e) => { console.error('Recognition error', e); };
}

function startRecognition(){ if(recognition) recognition.start(); speak('Voice recognition started'); }
function stopRecognition(){ if(recognition) recognition.stop(); speak('Voice recognition stopped'); }

function parseCommand(text){
  // basic command patterns
  if(text.includes('read page') || text.includes('read') ){
    // read main content
    const toRead = document.querySelector('main').innerText;
    speak(toRead);
    return;
  }
  if(text.includes('scroll down')){ window.scrollBy({top:300,behavior:'smooth'}); speak('Scrolling down'); return; }
  if(text.includes('scroll up')){ window.scrollBy({top:-300,behavior:'smooth'}); speak('Scrolling up'); return; }
  if(text.match(/open item (\d+)/)){
    const m = text.match(/open item (\d+)/);
    const idx = parseInt(m[1],10)-1; speak('Opening item number '+(idx+1));
    const el = document.querySelectorAll('.product')[idx];
    if(el) el.scrollIntoView({behavior:'smooth'});
    return;
  }
  if(text.match(/add to cart( item)? (\d+)/)){
    const m = text.match(/add to cart( item)? (\d+)/);
    const idx = parseInt(m[2],10)-1; addToCartByIndex(idx); return;
  }
  if(text.includes('show cart') || text.includes('open cart')){ speak('Showing your cart'); renderCart(); return; }
  if(text.includes('increase font') || text.includes('bigger')){ changeFont(2); return; }
  if(text.includes('decrease font') || text.includes('smaller')){ changeFont(-2); return; }
  if(text.includes('toggle contrast')){ toggleContrast(); return; }
  if(text.includes('stop reading') || text.includes('stop')){ stopSpeaking(); return; }
  // fallback
  speak('Command not recognized. Try say read page, scroll down, open item one, or add to cart two.');
}

// --- Wire UI ---
voiceStartBtn.addEventListener('click', ()=> startRecognition());
voiceStopBtn.addEventListener('click', ()=> stopRecognition());

toggleContrastBtn.addEventListener('click', ()=> toggleContrast());
increaseFontBtn.addEventListener('click', ()=> changeFont(2));
decreaseFontBtn.addEventListener('click', ()=> changeFont(-2));

// load data + init
loadProducts();
renderCart();

// speak welcome
speak('Welcome to Blind Navigator demo. Say Read page to start.');
